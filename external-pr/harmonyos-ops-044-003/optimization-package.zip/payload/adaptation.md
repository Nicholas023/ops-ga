# Local adaptation: running ops-ga on a host that cannot enforce a sandbox

Status: implemented, tested offline only (no paid model call was made while preparing this note).
Scope: `src/` and `test/` only. `bin/`, `lanes/`, `examples/`, `README.md`, `package.json` untouched.
This note is gitignored by the repo's own `**/*.md` rule; it is meant to be copied into the
submission's `reproduce.json`.

## 1. Why the stock tool cannot run here

ops-ga historically allowed only `runner.permission` `read-only` or `workspace-write`, and the
README's Security boundary says "Do not grant `danger-full-access` to benchmark runs". That is the
correct default on a host that can confine a process. This host cannot.

Measured on the actual machine (HarmonyOS MNT-W72C, KirinX90, Node v26.10.0):

```text
$ node -p "process.version + ' ' + process.platform + ' ' + process.arch"
v26.10.0 openharmony arm64

$ command -v bwrap
(not found; exit 1)

$ node harmonyos/dsh-harmonyos.mjs --print-sandbox-plan
sandbox: NOT enforceable (the kernel killed the Landlock probe with SIGSYS) — would set DSH_PERMISSION_MODE=danger-full-access

$ native/system/packages/openharmony-arm64/bin/landlock-run --probe
Bad system call (core dumped)          # shell diagnostic, exit 159 = 128 + 31 (SIGSYS)
$ echo $?
159
```

Source-level reason (DSH checkout `dsh-rc2`):

- `packages/sandbox/sandbox-local/src/index.ts` defines
  `PLATFORM_CHAINS = { linux: ['bwrap','landlock'], darwin: ['seatbelt'], win32: ['windows-acl'] }`.
  `process.platform === 'openharmony'` has no chain entry, so `chainVerdict()` returns
  `'unavailable'` and `confine()` throws `SandboxUnavailableError(mode)`.
- That error is fail-closed by design: "refusing to run the command unconfined ... otherwise switch
  the consumer to danger-full-access" (from `packages/sandbox/sandbox/src/index.ts`).
- The HarmonyOS launcher (`harmonyos/dsh-harmonyos.mjs`) exists precisely for this: its functional
  probe dies with SIGSYS, and it then runs with `DSH_PERMISSION_MODE=danger-full-access`.

So on this host every real ops-ga evaluation fails at the first tool call under
`read-only`/`workspace-write`. Running the benchmark honestly therefore needs the recorded
`danger-full-access` exception, not a silent relaxation.

## 2. What changed

```text
src/config.mjs   +17 -1   permission validation: default refusal kept; explicit measured exception added
src/runner.mjs   +11 -2   sandboxRecord() helper; evaluation result + private receipt carry the truth
src/search.mjs   +13 -8   lane state / state.final / candidate.json / export artifact carry the truth
test/unenforced-sandbox.test.mjs  new     5 tests: refusal, acceptance, unchanged modes, mock, propagation
```

### New config keys (only valid together with `permission: "danger-full-access"`)

| Key | Type | Meaning |
| --- | --- | --- |
| `runner.acknowledgeUnenforcedSandbox` | `true` (literal boolean) | Operator confirms this host cannot enforce a kernel sandbox. |
| `runner.sandboxEvidence` | string, 10-500 chars, single line, no placeholder tokens | One-line measured proof (the command output above). |

Rules, all enforced by `readConfig` before anything runs:

1. `danger-full-access` without both keys is still rejected
   ("danger-full-access requires explicit acknowledgeUnenforcedSandbox: true" /
   "... requires measured single-line sandboxEvidence").
2. The two keys may **not** appear with `read-only`/`workspace-write`
   ("Unenforced-sandbox fields require danger-full-access"), so a config cannot carry a stale or
   misleading acknowledgment.
3. Unknown permission strings are rejected ("runner.permission must be read-only, workspace-write or
   danger-full-access").
4. `read-only`/`workspace-write` validation, runtime patch and evaluation path are byte-for-byte
   unchanged. On this host they still fail closed at the sandbox exactly as before.
5. Mock runs are unaffected and never carry sandbox labels.

### Propagation ("no artifact may silently claim kernel confinement")

When the run is unenforced, every artifact below contains `"sandboxEnforced": false` and
`"sandboxEvidence": "<the measured one-liner>"`:

| Artifact | Where |
| --- | --- |
| Every evaluation record | `state.json -> evaluations[*]`, in-memory results |
| Per-episode private receipt | `episodes/<candidate>/<split>/<task>/receipt.json` |
| Lane state | `state.json` top level |
| `state.final` | held-out validation result, also returned by `validateFinal` |
| `candidate.json` | tuning-gate winner artifact |
| Export artifact | file written by `exportWinner` |

In every other mode the keys are absent (an absent key is "no claim", never "enforced"). Mock
records keep only `synthetic: true`, so a mock run cannot be mistaken for an unenforced real run or
the other way round. `withState` also refuses to resume a directory whose recorded enforcement
status disagrees with the current config ("Sandbox enforcement record changed: choose a new output
directory"); in practice the config fingerprint already forces a new directory.

## 3. Tests

```text
$ cd ops-ga && npm test
...
✔ danger-full-access stays refused unless acknowledgment and measured evidence are both explicit
✔ danger-full-access is accepted only with the exception, and is labeled unenforced
✔ read-only and workspace-write validation and labels are unchanged
✔ mock run artifacts never claim a sandbox status
✔ unenforced run carries sandboxEnforced:false and the evidence into every artifact
ℹ tests 33
ℹ pass 32
ℹ fail 0
ℹ skipped 1   (pre-existing Windows-only test)
```

The unenforced-run test uses an offline fake DSH process that emits the same headless JSON event
stream as the real CLI; it makes no provider call. It also exercises the export artifact.

## 4. Real-run config snippet

Keep every existing value of the lead's `ops-ga.local.json` and change/add exactly these three
lines in `runner` (measured on this host, so copy-paste safe):

```json
"permission": "danger-full-access",
"acknowledgeUnenforcedSandbox": true,
"sandboxEvidence": "sandbox: NOT enforceable (the kernel killed the Landlock probe with SIGSYS); landlock-run --probe exit 159 on HarmonyOS MNT-W72C"
```

Full runner block as used for the real run (values from `.ops-ga-local/ops-ga.local.json`; the
output directory must be a fresh path because the config fingerprint binds it):

```json
"output": "/redacted/home/Desktop/Plugins/.ops-ga-local/.runs/run-real-001",
"runner": {
  "type": "dsh",
  "command": "/redacted/home/.harmonybrew/bin/node",
  "args": ["/redacted/home/harness-src/dsh-rc2/apps/cli/lib/bin.js"],
  "home": "/redacted/home/Desktop/Plugins/.ops-ga-local/dsh-home",
  "profile": "headless",
  "provider": "deepseek-official",
  "model": "deepseek-flash",
  "reasoningEffort": "high",
  "permission": "danger-full-access",
  "acknowledgeUnenforcedSandbox": true,
  "sandboxEvidence": "sandbox: NOT enforceable (the kernel killed the Landlock probe with SIGSYS); landlock-run --probe exit 159 on HarmonyOS MNT-W72C",
  "timeoutMs": 300000,
  "acknowledgeIsolation": true,
  "captureSessions": true,
  "provenance": { "dsh": "...existing pinned value...", "ops": "...existing pinned value..." }
}
```

This exact config (with the real provenance strings) was dry-validated with `readConfig`: accepted,
permission `danger-full-access`, and `sandboxRecord()` returned
`{"sandboxEnforced":false,"sandboxEvidence":"..."}`. No inference was run during validation.

Operational notes for the paid run:

- `DSH_PERMISSION_MODE=danger-full-access` and the `sandbox-policy` runtime patch both come from
  `runner.permission`, so the child DSH actually runs unconfined (verified in DSH source:
  `fs-sandbox` and `terminal-bash` delegate unfenced for `danger-full-access`).
- `search.llmMutation: true` still launches the optimizer session under `read-only` (protected
  behavior, intentionally unchanged). On this host a read-only *tool call* would throw
  `SandboxUnavailableError`; the optimizer patch disables tools, so it should not happen, but if
  that session misbehaves, set `"llmMutation": false` — the search then uses deterministic
  breeding only. This is the conservative option for the unenforced host.
- Benchmark semantics are unchanged: this mode does not make scores more valid and does not prove
  sandbox preservation. It records the opposite: `sandboxEnforced: false` in every artifact.

## 5. How to re-check

```sh
cd ops-ga && npm test
node bin/ops-ga.mjs doctor --config /path/to/ops-ga.local.json     # offline config/CLI check, no inference
node bin/ops-ga.mjs run --config /path/to/ops-ga.local.json --lane operations --allow-paid
node bin/ops-ga.mjs validate --config /path/to/ops-ga.local.json --lane operations --allow-paid
```
