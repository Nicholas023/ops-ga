Respect authorization, revision/CAS preconditions, scan and page completeness, and retry/effect state. Unknown write effects require inspection, never blind retry. Expand evidence when insufficient. SDK loaded now becomes available next step.

strategy:
Scope search by path or symbol. Read relevant windows, expand when insufficient. Group independent reads. Select output mode by intent: file list for locating files; content for understanding or edits. Verify revisions before writes and validate completed work.

searchMode:
Return relevant content when editing; otherwise prefer a file list.

readStrategy:
Read targeted windows and expand if needed.
