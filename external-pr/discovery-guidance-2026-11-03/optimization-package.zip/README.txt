optimization package for the discovery lane: candidate genome, history, ledger, official per-arm reports and the paired evidence payload.
